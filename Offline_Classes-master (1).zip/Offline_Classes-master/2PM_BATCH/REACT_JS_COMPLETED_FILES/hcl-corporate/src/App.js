import React from 'react';
import './App.css';
import Navbar from "./components/Navbar";
import Jumbotron from "./components/Jumbotron";
import Card from "./components/Card";
import Footer from "./components/Footer";

function App() {
  return (
    <div>
       <Navbar/>
       <Jumbotron/>
        <div className="container-fluid">
            <div className="row">
                <div className="col-md-3">
                    <Card name='John' age='40' designation='Manager'/>
                </div>
                <div className="col-md-3">
                    <Card name='Wilson' age='45' designation='Sr.Manager'/>
                </div>
                <div className="col-md-3">
                    <Card name='Rajan' age='23' designation='Sf Engineer'/>
                </div>
                <div className="col-md-3">
                    <Card name='Mahesh' age='30' designation='Tech Lead'/>
                </div>
            </div>
        </div>
       <Footer/>
    </div>
  );
}

export default App;

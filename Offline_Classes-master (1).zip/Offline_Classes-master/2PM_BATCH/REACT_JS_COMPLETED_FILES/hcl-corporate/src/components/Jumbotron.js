import React , {Component} from 'react';

class Jumbotron extends  Component{
    render() {
        return(
            <div>
                <div className="jumbotron">
                    <h1 className="display-4 text-primary">Welcome to HCL Corporate</h1>
                    <p className="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. A at cumque delectus excepturi, fugiat iste neque quas quisquam sunt unde? A accusamus architecto beatae cupiditate debitis ex excepturi illum impedit molestias mollitia nulla numquam obcaecati quo, ratione repudiandae soluta voluptatum.</p>
                    <p className="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aut beatae commodi consectetur cum dolorem doloremque error exercitationem incidunt omnis optio provident, quo. Alias amet dignissimos ex laboriosam neque numquam obcaecati provident quo unde, vitae. Ab alias aut consequatur debitis dignissimos dolorum enim eos, expedita, impedit minima neque officiis reprehenderit voluptates!</p>
                    <p className="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit. A at cumque delectus excepturi, fugiat iste neque quas quisquam sunt unde? A accusamus architecto beatae cupiditate debitis ex excepturi illum impedit molestias mollitia nulla numquam obcaecati quo, ratione repudiandae soluta voluptatum.</p>
                    <hr className="my-4"/>
                        <p>It uses utility classes for typography and spacing to space content out within the larger
                            container.</p>
                        <a className="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
                </div>
            </div>
        )
    }
}
export  default Jumbotron;
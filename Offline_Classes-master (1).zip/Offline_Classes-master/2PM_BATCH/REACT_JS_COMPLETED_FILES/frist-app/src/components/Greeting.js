import React , {Component} from 'react';

class Greeting extends Component{
    render() {
        return(
            <div>
                <h1 className='orange'>Welcome to Class based Component</h1>
            </div>
        );
    }
}
export  default Greeting;